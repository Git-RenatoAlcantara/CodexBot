<?php
/**
 Webhook de retorno. Recebe a resposta de pagamento da API do Mercado Pago,
verifica no banco se o cliente existe e retorna o id do chat.
**/

include("criarUsuario.php");
include("database.php");

function selecionarPagamento($paymentid, $conn){
    
   $getChatId = "";
   
   $query= "SELECT * FROM Pagamentos";
    
    $result = $conn->query($query);
    
    if($result->num_rows > 0){
        $cont = 0;
        while($row = $result->fetch_assoc()){
           //  print_r($row);
             
             if($row["paymentid"]== $paymentid){
                 $getChatId = $row["chatid"];
             }
        }
    }
    
    return $getChatId;
}

/**if(isset($_GET) && !empty($_GET["paymentId"])){
   
    $paymentId = $_GET["paymentId"];
 
   $conn = connect();
   if(!empty($conn)){
      $result =  selecionarPagamento($conn, $paymentId);
        if(empty($result)) echo "vazio";
        if(!empty($result)) echo $result;
   }
    
}
**/
function enviarUsuario($chatId, $sshUser, $sshPass){
 $apiToken = "5364826966:AAGfUb1i8HZsEHbHPfUmnxerkbITyig_WJk";
 $html ="
 <b>Conta criada comfunction sucesso!</b>
 
 <b>Usuário:</b> <i> $sshUser</i>
 <b>Senha:</b><i> $sshPass</i>
 <b>Validade:</b> 30 Dias
 <b>VIVO | TIM | CLARO</b>
 
 <b>Contato:</b> @N00neMod";
$data = [
      'chat_id' => $chatId,
      'text' => $html,
      'parse_mode' => 'html'
  ];
  

$url= "https://api.telegram.org/bot".$apiToken."/sendMessage?parse_mode=HTML&chat_id=".$chatId."&text=".urlencode($html);

file_get_contents($url);
}
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $post = file_get_contents('php://input');
    $array = (array) json_decode($post);
    $database = new DataBase();
    $conn = $database->getConnect();
    if ($mysqli->connect_error) {
        die('Connect Error (' . $mysqli->connect_errno . ') '. $mysqli->connect_error);
    }


    if(!empty($array["action"])){
       
        $data = $array["data"];
        $id = (array) $data;
        $database = new DataBase();
        $conn = $database->getConnect();
        if ($mysqli->connect_error) 
         {
           die('Connect Error (' . $mysqli->connect_errno . ') '. $mysqli->connect_error);
         }
        
         // Recebe json da API Mercado pago e verifica no banco de dados se existe um pedido
        // Caso exista devolve o id do chat do cliente
        $chatId = selecionarPagamento($id["id"], $conn);
      
        // Chama a classe CriarUsuario e gera o usuario e senha automaticamente randomizado
        if(!empty($chatId)){
          $criar = new CriarUsuario();
          $response = $criar->ssh_connect($chatId);
          echo $response;
        }else{
          echo "Numero do pedido nao existe!";
        }
        
        //$chatId = selecionarPagamento($id["id"], );
        //header('Content-Type: application/json');
    }
    
}else if (isset($_GET)){
    echo "GET";
    
}

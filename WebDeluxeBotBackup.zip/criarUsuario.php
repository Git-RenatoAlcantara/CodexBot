<?php

include "Net/SSH2.php";

class CriarUsuario {
  

function ssh_connect($chatId){
  $ssh = new Net_SSH2('152.67.45.192');
  if (!$ssh->login('root', 'Renato$96475870')) {
      exit('Login Failed');
  }
    $response = $this->create_user();
    $user=$response["user"];
    $pass=$response["pass"];
    $expire=$response["expire"];
    $limite=$response["limite"];
    
    echo $ssh->exec('./criarUsuario.sh '.$user.' '.$pass.' '.$expire.' '.$limite.' '.$chatId);
  
}

function create_user(){
      
      $date = new DateTime();
      $timestamp=$date->getTimestamp();
      $sufixo= str_split($timestamp, 5);
      $base = "codex";
      $pass = $sufixo[0];
      $user = $base.''.$sufixo[1];
      $expire = "30";
      $limite = "1";

      $payload = array("user" => $user,
      "pass" => $pass,
      "expire" => $expire,
      "limite" => $limite);

       return $payload;
   }

   
}


//header('Content-Type: application/json');

//echo json_encode($payload);(
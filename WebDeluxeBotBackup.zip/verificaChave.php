<?php
include("database.php");

$sufix="4a90503b8a8ab37f1547582c948a8df4022696e8";
//$chave="16546501364a90503b8a8ab37f1547582c948a8df4022696e8";
//5364826966:AAGfUb1i8HZsEHbHPfUmnxerkbITyig_WJk

function gerarChave(){
for ($i = 0, $z = strlen($a = '1234567890')-1, $s = $a{
     rand(0,$z)
     }, $i = 1; $i != 20; $x = rand(0,$z), $s .= $a{$x}, $s = ($s{$i} == $s{$i-1} ? substr($s,0,-1) : $s), 
     $i=strlen($s));
  echo $i;
  
return  $s;
}


function selecionarChave($chave, $conn){
    
   $checked = false;
   
   $query= "SELECT * FROM Registros";
    
    $result = $conn->query($query);
    
    if($result->num_rows > 0){
        $cont = 0;
        while($row = $result->fetch_assoc()){
           //  print_r($row);
            
              if($row["chave"] == $chave ){
                $checked = !$checked;
                
              }
           
        }
    }

    return $checked;
}

function inserirDados($chave, $conn){

$query = "INSERT INTO Registros (chave)
VALUES ($chave)";

if ($conn->query($query) === TRUE) 
{
  return true;
} else 
{
  return false;
}

}


function criarTabela($conn){
   // código sql para criar a tabela
// sql to create table
$sql = "CREATE TABLE IF NOT EXISTS Registros (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
chave VARCHAR(200) NOT NULL,
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

  if ($conn->query($sql) === TRUE) {
  return true;
} else {
   return false;
}

}

if(isset($_POST)){
   $key=$_POST["key"];
   $payload = "";

  $database = new DataBase();
  $conn = $database->getConnect();
  
  
  if(selecionarChave($key, $conn)){
   $result = array("validate" => "Success");
   $payload = json_encode($result);
   header('Content-Type: application/json');
    echo $payload;
    
   }else{
     $result = array("validate" => "Failed");
     $payload = json_encode($result);
    header('Content-Type: application/json');
    echo $payload;
 }

}else if(isset($_GET))
{
  $database = new DataBase();
  $conn = $database->getConnect();
  

if ($mysqli->connect_error) 
 {
      die('Connect Error (' . $mysqli->connect_errno . ') '. $mysqli->connect_error);
 }

if(criarTabela($conn))
{
    $chave = gerarChave();
   if(inserirDados($chave , $conn))
   {
    echo $chave;
    }else{
     echo "Nao salvo";
   }


 }


  
}
  
?>

<?php
class Database{
  
function getConnect(){
   
   $servername = "sql10.freesqldatabase.com";
   $username = "sql10498176";
   $password = "LukIsTjSlR";
   $dbname   = "sql10498176";

  $conn = new mysqli($servername, $username, $password, $dbname);
    return $conn;
  }
  
}